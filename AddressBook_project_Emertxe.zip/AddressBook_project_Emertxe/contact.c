#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

/*Name :Jayasree G
roll:24019_031
date of submission: 21-10-2024
*/


void listContacts(AddressBook *addressBook) 
{

    int count=addressBook->contactCount;
   // printf("count= %d",count);
    if(count==0)
    {
        printf("No Contacts to display .\n");
        return;
    }
    printf("----------------------------------------\n");
    printf("Name\t\tPhone\t\tEmail\n");
    for(int i=0;i<count;i++)
    {
        printf("%s\t",addressBook->contacts[i].name);
        printf("%s\t",addressBook->contacts[i].phone);
        printf("%s\t",addressBook->contacts[i].email);
        printf("\n");
    }
    printf("\n");

}

void initialize(AddressBook *addressBook) 
{
 //no need for this function since we are using loadcontacts from file function   
  populateAddressBook(addressBook);

}

void saveAndExit(AddressBook *addressBook) 
{
    printf("Do you want to save changes(y/n):");
    char choice;
    scanf(" %c",&choice);
    if(choice== 'y' || choice == 'Y')
    {
        saveContactsToFile(addressBook);
        printf("Contacts saved successfully to file.\n");


    }
    else
    {
        printf("Changes are not saved!\n");
        
    }
   return;
}


void createContact(AddressBook *addressBook) 
{
    //ask the user for name and details and create one at last
    //validate phone and email they should be unique
    
    //checking for count of addressbook

    if (addressBook->contactCount >= MAX_CONTACTS)
    {
      printf("Contact book is full.\n");
      return;
    }

     Contact newContact;
     int isDuplicate;

// Input Name
  printf("Enter the name: ");
  clearInputBuffer();  // Clear any leftover input
  scanf(" %[^\n]%*c", newContact.name);  // Handles spaces in the name and flushes newline

// Input Phone Number with duplicate check
do
{
    isDuplicate = 0;
    printf("Enter Phone Number: ");
    scanf("%s", newContact.phone);

    for (int i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(newContact.phone, addressBook->contacts[i].phone) == 0)
        {
            isDuplicate = 1;
            printf("Phone number already exists!\n");
            break;
        }
    }

} while (isDuplicate);

clearInputBuffer();  // Clear any leftover input

// Input Email with duplicate check
do
{
    isDuplicate = 0;
    printf("Enter Email Address: ");
    fgets(newContact.email, sizeof(newContact.email), stdin);
    newContact.email[strcspn(newContact.email, "\n")] = '\0';  // Remove newline character

    for (int i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(newContact.email, addressBook->contacts[i].email) == 0)
        {
            isDuplicate = 1;
            printf("Email address already exists! \n");
            break;
        }
    }
 
} while (isDuplicate);

// Store new contact in the address book
   addressBook->contacts[addressBook->contactCount] = newContact;
   addressBook->contactCount++;

   printf("Contact Created Successfully.\n");

}
void searchContact(AddressBook *addressBook) 
{
    
    //read the name from user
    // search for name in contacts[]
    //loop for contactcount 
    //strcmp of names
    


 clearInputBuffer();  // Clear any leftover input

    char name[50];
    printf("Enter the name to search: ");
    fgets(name, sizeof(name), stdin);
    name[strcspn(name, "\n")] = '\0'; // Remove newline

    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(addressBook->contacts[i].name, name) == 0) {
            printf("Contact found !\n");
            printf("Name: %s\t", addressBook->contacts[i].name);
            printf("Phone: %s\t", addressBook->contacts[i].phone);
            printf("Email: %s\t", addressBook->contacts[i].email);
            printf("\n");
            return;
        }
    }
    printf("Contact not found.\n");




}

void editContact(AddressBook *addressBook) 
{
    //read name from the user to edit that contact
    //search for contact 
    //get new details
     clearInputBuffer();

    char searchTerm[50];
    int matches[100]; // To store the indices of matching contacts
    int matchCount = 0; // Number of matches found

    printf("Enter the contact to edit: ");
    fgets(searchTerm, sizeof(searchTerm), stdin);
    searchTerm[strcspn(searchTerm, "\n")] = '\0'; // Remove newline

    // Search for matches in name, phone, or email
    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(addressBook->contacts[i].name, searchTerm) == 0 ||
            strcmp(addressBook->contacts[i].phone, searchTerm) == 0 ||
            strcmp(addressBook->contacts[i].email, searchTerm) == 0) {
            matches[matchCount++] = i; // Save the index of the match
        }
    }

    if (matchCount == 0) {
        printf("No contacts found matching '%s'.\n", searchTerm);
        return;
    }

    // Display all matched contacts
    printf("Contacts found matching '%s':\n", searchTerm);
    for (int i = 0; i < matchCount; i++) {
        int index = matches[i];
        printf("%d. Name: %s, Phone: %s, Email: %s\n", i + 1, addressBook->contacts[index].name,
                addressBook->contacts[index].phone, addressBook->contacts[index].email);
    }

    // If multiple matches, ask user which one to edit
    int choice = 0;
    if (matchCount > 1) {
        printf("Enter the number of the contact you want to edit: ");
        scanf("%d", &choice);
        getchar(); // Clear the newline character left in the buffer
        choice--;  // Adjust for zero-based index
        if (choice < 0 || choice >= matchCount) {
            printf("Invalid choice.\n");
            return;
        }
    }

    int contactIndex = matches[choice];
    //Ask for new Name
    printf("Enter the new Name :");
    fgets(addressBook->contacts[contactIndex].name,sizeof(addressBook->contacts[contactIndex].name),stdin);
    addressBook->contacts[contactIndex].name[strcspn(addressBook->contacts[contactIndex].name, "\n")]='\0';

    // Ask for new phone number
    printf("Enter new phone number :");
    fgets(addressBook->contacts[contactIndex].phone, sizeof(addressBook->contacts[contactIndex].phone), stdin);
    addressBook->contacts[contactIndex].phone[strcspn(addressBook->contacts[contactIndex].phone, "\n")] = '\0'; // Remove newline

    // Ask for new email address
    printf("Enter new email address :");
    fgets(addressBook->contacts[contactIndex].email, sizeof(addressBook->contacts[contactIndex].email), stdin);
    addressBook->contacts[contactIndex].email[strcspn(addressBook->contacts[contactIndex].email, "\n")] = '\0'; // Remove newline

    printf("Contact updated successfully.\n");



}

void deleteContact(AddressBook *addressBook) 
{
    clearInputBuffer();

    char searchTerm[50];
    int matches[100];  // To store indices of matching contacts
    int matchCount = 0; // Number of matches found

    printf("Enter the contact to delete: ");
    fgets(searchTerm, sizeof(searchTerm), stdin);
    searchTerm[strcspn(searchTerm, "\n")] = '\0'; // Remove newline

    // Search for matching contacts in name, phone, or email
    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(addressBook->contacts[i].name, searchTerm) == 0 ||
            strcmp(addressBook->contacts[i].phone, searchTerm) == 0 ||
            strcmp(addressBook->contacts[i].email, searchTerm) == 0) {
            matches[matchCount++] = i; // Store index of the match
        }
    }

    if (matchCount == 0) {
        printf("No contacts found matching '%s'.\n", searchTerm);
        return;
    }

    // Display all matched contacts
    printf("Contacts found matching '%s':\n", searchTerm);
    for (int i = 0; i < matchCount; i++) {
        int index = matches[i];
        printf("%d. Name: %s, Phone: %s, Email: %s\n", i + 1, addressBook->contacts[index].name,
               addressBook->contacts[index].phone, addressBook->contacts[index].email);
    }

    // If multiple matches, ask the user which one to delete
    int choice = 0;
    if (matchCount > 1) {
        printf("Enter the number of the contact you want to delete: ");
        scanf("%d", &choice);
        getchar(); // Clear the newline character left in the buffer
        choice--;  // Adjust for zero-based index
        if (choice < 0 || choice >= matchCount) {
            printf("Invalid choice.\n");
            return;
        }
    }

    int contactIndex = matches[choice];

      // Shift all contacts after the deleted one
        for (int i = contactIndex; i < addressBook->contactCount - 1; i++) 
        {
            addressBook->contacts[i] = addressBook->contacts[i + 1];
        }

        // Reduce the contact count
        addressBook->contactCount--;
        printf("Contact deleted successfully.\n");
     
    

}



void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF); // Clear the input buffer
}


