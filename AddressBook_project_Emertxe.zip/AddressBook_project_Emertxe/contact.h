#ifndef CONTACT_H
#define CONTACT_H


/*Name :Jayasree G
roll:24019_031
date of submission: 21-10-2024
*/


#define MAX_CONTACTS 100
#include<stdlib.h>
#include<stdio.h>

typedef struct {
    char name[50];
    char phone[20];
    char email[50];
} Contact;

typedef struct {
    Contact *contacts;
    int contactCount;
    FILE *ptr;
} AddressBook;

void createContact(AddressBook *addressBook);
void searchContact(AddressBook *addressBook);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook);
void initialize(AddressBook *addressBook);
void saveContactsToFile(AddressBook *AddressBook);
void saveAndExit(AddressBook *addressBook);
void clearInputBuffer() ;

#endif
