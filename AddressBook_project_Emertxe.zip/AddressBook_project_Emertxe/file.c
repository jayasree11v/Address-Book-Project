#include <stdio.h>
#include "file.h"
#include<stdlib.h>
#include<string.h>
#include "contact.h"

/*Name :Jayasree G
roll:24019_031
date of submission: 21-10-2024
*/

void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *file = fopen("addressbook.csv", "w");
    if (file == NULL)
    {
        printf("Could not open file for writing.\n");
        return;
    }

    // Write the total number of contacts in the first line
    fprintf(file, "#%d#\n", addressBook->contactCount);

    // Loop through the contacts and write each one in CSV format
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        Contact contact = addressBook->contacts[i];
        fprintf(file, "%s,%s,%s", contact.name, contact.phone, contact.email);
    }

    fclose(file);
    
}

void loadContactsFromFile(AddressBook *addressBook) 
{
    
    char line[150];
    int allocatedSize = 10; // Initial allocation size (can be any reasonable number)
    addressBook->contactCount = 0;

    // Initially allocate memory for some contacts
    addressBook->contacts = (Contact *)malloc(allocatedSize * sizeof(Contact));
    if (addressBook->contacts == NULL)
    {
        printf("Initial memory allocation failed!\n");
        return;
    }

    // Read the first line to get the contact count
    if (fgets(line, sizeof(line), addressBook->ptr) != NULL)
    {
        char *token = strtok(line, "#");
        token = strtok(NULL, "#");
        int fileContactCount = 0;
        
        if (token != NULL)
        {
            fileContactCount = atoi(token);
           // printf("File contact count: %d\n", fileContactCount);
        }

        // Loop to read each contact
        while (fgets(line, sizeof(line), addressBook->ptr))
        {
            // If the current contact count reaches the allocated size, double the allocated size
            if (addressBook->contactCount >= allocatedSize)
            {
                allocatedSize *= 2; // Double the allocated size
                addressBook->contacts = (Contact *)realloc(addressBook->contacts, allocatedSize * sizeof(Contact));
                if (addressBook->contacts == NULL)
                {
                    printf("Memory reallocation failed!\n");
                    return;
                }
            }

            Contact contact;

            token = strtok(line, ",");
            if (token != NULL) strcpy(contact.name, token);

            token = strtok(NULL, ",");
            if (token != NULL) strcpy(contact.phone, token);

            token = strtok(NULL, ",");
            if (token != NULL) strcpy(contact.email, token);

            // Store the contact in the array
            addressBook->contacts[addressBook->contactCount] = contact;
            addressBook->contactCount++;
        }
    }    
}

