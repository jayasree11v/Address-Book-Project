#ifndef FILE_H
#define FILE_H

#include "contact.h"
//file realted functions

/*Name :Jayasree G
roll:24019_031
date of submission: 21-10-2024
*/


void saveContactsToFile(AddressBook *addressBook);
void loadContactsFromFile(AddressBook *addressBook);

#endif
