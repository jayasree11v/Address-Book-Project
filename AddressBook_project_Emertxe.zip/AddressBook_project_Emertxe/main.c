#include <stdio.h>
#include "contact.h"
#include "file.h"
#include <stdlib.h>

/*Name :Jayasree G
roll:24019_031
date of submission: 21-10-2024
*/


int main() 
{
    //1.display menu for user
    //2.take choice from user
    //3.switch case
    AddressBook book;//structure variable
//    initialize(&book);//fun call
    book.ptr=fopen("Addressbook.csv","r+");//opening file in r+ mode
    if(book.ptr==NULL)
    {
        printf("Could not open file !\n");
        return 0;
    }

  
    loadContactsFromFile(&book);
   // printf("%d Contacts loaded successfully \n ",book.contactCount);
    fclose(book.ptr);
        


    int choice;
    do
    {
        printf("ADDRESS BOOK MENU :\n\n");
        printf("1.Search Contact\n");
        printf("2.Create Contact\n");
        printf("3.Edit Contact\n");
        printf("4.Delete Contact\n");
        printf("5.List all Contacts\n");
        printf("6.Exit\n");
        printf("Enter your choice :\n");
        
        scanf("%d",&choice);

        switch(choice)
        {
            case 1:
               // printf("Search\n");
                searchContact(&book);
                break;

            case 2:
                //printf("Create\n");
               createContact(&book);
                break;

            case 3:
               // printf("Edit\n");
                editContact(&book);
                break;

            case 4:
                //printf("Delete\n");
                deleteContact(&book);
                break;
            case 5:
               // printf("List\n");
                listContacts(&book);
                break;
            case 6:
                
                saveAndExit(&book);

                return 0;

        }

    }while(choice>0 && choice<=6);

}
