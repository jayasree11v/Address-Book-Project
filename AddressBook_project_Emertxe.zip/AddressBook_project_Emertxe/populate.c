#include "contact.h"
#include<string.h>
#include<stdio.h>

/*Name :Jayasree G
roll:24019_031
date of submission: 21-10-2024
*/


// Dummy contact data
static Contact dummyContacts[] = {
    {"John Doe", "1234567890", "john@example.com"},
    {"Alice Smith", "0987654321", "alice@example.com"},
    {"Bob Johnson", "1112223333", "bob@company.com"},
    {"Carol White", "4445556666", "carol@company.com"},
    {"David Brown", "7778889999", "david@example.com"},
    {"Eve Davis", "6665554444", "eve@example.com"},
    {"Frank Miller", "3334445555", "frank@example.com"},
    {"Grace Wilson", "2223334444", "grace@example.com"},
    {"Hannah Clark", "5556667777", "hannah@example.com"},
    {"Ian Lewis", "8889990000", "ian@example.com"}
};

void populateAddressBook(AddressBook* addressBook)
{
    //copy dummy contacts to array contacts[MAX_CONTACTS];
    //find size of dummy contacts sizeof(arr)/sizeof(arr[0])
    //we dont have access to dummy contacts so calling populateaddressbook from init fun
    addressBook->contactCount=0;
    for(int i=0;i<sizeof(dummyContacts)/sizeof(dummyContacts[0]);i++)
    {
       
        addressBook->contacts[i]=dummyContacts[i];
        addressBook->contactCount++;
    }
}
//instead of dummycontacts array we are creating a separate file
//Addressbook.csv so that operations can be easilly done on it
