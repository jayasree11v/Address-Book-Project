#ifndef POPULATE_H
#define POPULATE_H

/*Name :Jayasree G
roll:24019_031
date of submission: 21-10-2024
*/


#include "contact.h"

void populateAddressBook(AddressBook *addressBook);

#endif // POPULATE_H

